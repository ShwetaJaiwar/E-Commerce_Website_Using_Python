# E-Commerce-Website-Using-Python
## Summary
Hello friends, This is my first full e-commerce project with Python-Flask. This is free. Anybody can use and moderate this project.

## Platform Used
### Front-End
  (i) HTML5 <br>
  (ii) CSS3 <br>
  (iii) JavaScript <br>
  (iv) Bootstrap <br>

### Back-End
  (i) Python - Flask <br>
  (ii) MySQL <br>

## Key Features
### Public User
(i) Search Product <br>
(ii) View Product <br>
(iii) Create User Account <br>

### Signin User
(i) Search Product <br>
(ii) View Product <br>
(iii) Create Order <br>
(iv) Change Email & Password <br>
(v) Can View Previous Order with UPDATE and DELETE <br>

### Admin
(i) Add New Product <br>
(ii) Update Product <br>
(iii) See all Orders <br>
(iv) Manage all Users <br>

## Conclusion
There are also many more feature which are not in the list. Feel free to use this project
